# Start Notch Lore

Version: 2.0.0
Mode: chatgpt
Integrity: PACK_MANIFEST.json records every supplied file. Verify before importing project-specific instructions.

1. Attach this whole ZIP to a new ChatGPT chat. If ZIP reading is unavailable, extract it and attach its Markdown files.
2. Send this, replacing [goal] with what you want to achieve:

```text
notchlore. Use the attached pack in ChatGPT mode. My business goal is: [goal]. Propose the solution, develop the documents, and guide the next useful step.
```

You can also send "notchlore" or describe your goal naturally. Include existing project documents or a sanitized source dump when available; an idea alone is enough to begin.

The assistant develops a proposal and current documents, asks only consequential business or product questions, and proceeds in the selected mode. This archive supplies the approach, not your application code.

Read [GUIDE.md](GUIDE.md) for file transfer and continuation. The skill file is included as a reference; uploading this pack does not install it in Codex or connect Dot to a VPS.
